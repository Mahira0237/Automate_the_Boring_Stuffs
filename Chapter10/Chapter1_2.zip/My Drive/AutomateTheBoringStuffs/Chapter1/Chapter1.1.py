print(2+2)
print((2+3)*6)
print(2**8)
print(23/7)
print(23//7)
print(23%7)
print((5-1)*(7+1)/(3-1))

#Invalid syntax
#5+
#42+5*2

#EOL
#'Hello

#String
print('Alice' + 'Bob')

# can only concatenate string
# print('Alice'+ 42)

print('Alice'*5)

#cant multiply non-int 
#print('Alice'*'Bob')
#ccant multiply nonint float
#print('Alice'*5.0)

#Assignment
spam=40
print(spam)
eggs=2
print(spam + eggs)
print(spam+eggs+spam)
spam=spam+2
print(spam)

spam='Hello'
print(spam)
spam='Goodbye'
print(spam)