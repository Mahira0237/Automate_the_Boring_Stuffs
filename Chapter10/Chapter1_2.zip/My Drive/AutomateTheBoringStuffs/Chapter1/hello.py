#First Program 1

print('Hello,world!')
print('What is your name')
name=input()
print('It is good to meet you,'+name)
print('The length of your name is:')
print(len(name))
print('what is your age?')
age=input()
print('You will be ' + str(int(age)+1) + ' in a year')