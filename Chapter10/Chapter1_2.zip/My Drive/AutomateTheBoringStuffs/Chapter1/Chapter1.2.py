#len() function
print(len('hello'))
print(len('Autommate the Boring Stuffs'))
print(len(''))

#str(),int(),float()
#can only concatenate str 
#print('I am' + 25 + 'years old.')

print(str(29))
print('I am ' + str(25) + ' years old.')

print(str(0))
print(str(-3.14))
print(int('42'))
print(int(-99))
print(int(1.25))
print(int(1.99))
print(float('3.14'))
print(float(10))

spam=input()
#print(spam*10/5) input returns string
spam=int(spam)
print(spam*10/5)

#print(int('99.99')) 
#print(int('twelve'))
print(int(7.7))
print(int(7.7)+1)

print(42=='42')
print(42==42.0)
print(42.0==0042.000)

